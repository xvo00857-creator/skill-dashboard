---
name: feedback-triage
description: 智能随行杯用户反馈最小可用分诊工作流。输入用户反馈（JSON/JSONL），输出去重后的主题、优先级（P0-P3）和下一步行动；基于 product_brief.md 的卖点与禁区规则，结论与假设分开，外部数据列为待补项。
version: 0.1.0
risk: safe
source: local
tags:
  - feedback
  - triage
  - product
---

# feedback-triage v0.1.0

## 用途

针对「智能随行杯」新品，把零散用户反馈聚合成可执行清单：

1. **去重主题**：按受控主题词表归类，合并相同主题与重复反馈。
2. **优先级**：按严重度、反馈量、是否涉及安全合规、是否命中核心卖点计算 P0–P3。
3. **下一步行动**：每个主题给出可执行动作；需要外部数据的明确标为「待补项」。

本工作流为**最小可用（MVP）**：纯 Python 标准库、确定性规则、无外部 API/账号依赖。

## 何时使用

- 拿到一批用户反馈（评论、工单、访谈记录），需要快速分诊
- 需要输出主题、优先级、下一步行动三件套
- 需要严格遵守 product_brief.md 的「禁止编造」约束

## 不适用场景

- 需要情感分析模型、聚类算法或 LLM 语义理解（本版本为关键词规则）
- 需要真实销量、第三方检测、竞品价格等外部数据（这些只能列为待补项）

## 输入格式

JSON 数组或 JSONL（每行一个对象）。每条反馈：

| 字段 | 必填 | 说明 |
|------|------|------|
| `id` | 是 | 反馈唯一标识（字符串或数字） |
| `text` | 是 | 反馈正文 |
| `source` | 否 | 来源渠道 |
| `timestamp` | 否 | 时间戳（原样保留，不参与计算） |

## 命令

```bash
# JSON 数组输入，结果输出到 stdout
python scripts/triage.py examples/feedback_input.json

# JSONL 输入
python scripts/triage.py examples/feedback_input.jsonl

# 写入文件
python scripts/triage.py examples/feedback_input.json -o result.json

# 严格模式：任何被跳过的无效反馈都以非零码退出
python scripts/triage.py examples/feedback_input.json --strict
```

## 输出结构

```json
{
  "product": "智能随行杯",
  "summary": { "total_feedback": N, "unique_feedback": N, "duplicate_feedback": N,
               "theme_count": N, "p0": N, "p1": N, "p2": N, "p3": N },
  "themes": [
    {
      "theme_id": "insulation",
      "theme": "保温性能",
      "count": 2,
      "priority": "P1",
      "severity": "high",
      "is_safety_related": false,
      "is_core_selling_point": true,
      "feedback_ids": ["..."],
      "representative_feedback": "...",
      "next_actions": ["..."],
      "pending_items": ["..."]
    }
  ],
  "pending_items": ["..."],
  "assumptions": ["..."],
  "constraints": ["..."],
  "skipped": []
}
```

## 优先级规则

- **严重度**（按关键词）：critical（受伤/漏电/爆炸/中毒…）> high（漏水/不保温/坏了/异味/有毒…）> medium（难清洗/太重/色差/贵…）> low（建议/希望/有点…）
- **P0**：单条 critical；或安全/合规主题（材质食品、电子防水）严重度 ≥ high
- **P1**：高严重度且（命中核心卖点 或 同主题 ≥2 条）；或中严重度且同主题 ≥3 条
- **P2**：其余高严重度（非核心、单条）；或中严重度
- **P3**：严重度 low 或无明显负面

## 与 product_brief.md 的对齐

- 核心卖点：12 小时保温、280g、可拆洗杯盖 → 命中即升级优先级
- 禁止编造：第三方检测结论、销量、用户评价、竞品价格 → 脚本不会生成这些内容
- 待补项：首发日期、防水等级、食品接触材料报告 → 相关主题的下一步动作标为待补
- 结论与假设分开：输出含 `assumptions` 字段

## 失败处理

| 情况 | 行为 | 退出码 |
|------|------|--------|
| 文件不存在 | stderr 输出错误 JSON | 2 |
| JSON/JSONL 解析失败 | stderr 输出错误及位置 | 2 |
| 缺少 `id` 或 `text` | 该条进入 `skipped`，其余继续 | 0（`--strict` 时为 1） |
| 全部反馈无效 | 输出空主题 + `skipped` 明细 | 0（`--strict` 时为 1） |
| 编码错误 | stderr 提示用 UTF-8 | 2 |

## 局限性

- 关键词规则无法理解反讽、隐喻、上下文；复杂语义需后续接入模型
- 主题词表覆盖随行杯常见问题，新品类需扩充 `scripts/triage.py` 中的 `THEMES`
- 不调用任何外部服务，无法获取真实检测/销量/价格数据
