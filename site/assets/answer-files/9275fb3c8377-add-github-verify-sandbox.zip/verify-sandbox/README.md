# add-github 本地验证沙盒

本目录用于在**没有 NanoClaw 项目、没有外部账号**的条件下，可重复地验证
`add-github` Skill 中不依赖真实仓库/账号的机械部分。所有命令均可在本机直接重跑。

## 环境前提（已核实）

- node v20.19.2 / pnpm 10.34.5 / openssl(LibreSSL) 可用
- `ncl`、`gh` 未安装；本机不存在 NanoClaw 项目（无 `src/channels/index.ts`、无 `channels` 分支）
- `@chat-adapter/github@4.29.0` 在 npm 真实存在

## 一键复现

```bash
bash run-all.sh
```

四项检查全部应输出 PASS：

| 脚本 | 验证内容 | 对应 SKILL.md |
|---|---|---|
| verify-import.mjs | 精确版本 4.29.0 已安装、可导入，适配器 `name=github` | Apply 第 3、4 步；Troubleshooting“import 抛错” |
| verify-registry.mjs | 自注册 import 行幂等、registry 含 github；缺 import 时断言失败（模拟真实 vitest） | Apply 第 2 步；第 4 步 registration test |
| verify-webhook-signature.mjs | HMAC-SHA256 校验：secret 正确通过、错误失败（对应 401） | Credentials 第 2 步；Troubleshooting 401 |
| verify-env.sh | 三个环境变量 set-if-absent 幂等写入；`openssl rand -hex 20` 生成 40 位 secret | Credentials 第 2、3 步 |

## 最小配置产物

- `.env.example`：三个必填环境变量模板
- `ncl-wiring.example.sh`：消息组创建、agent 组接线、strict 模式加成员的命令模板
  （**确认前步骤**：需 ncl + 运行中的 host 服务后才能执行，本次不执行）

## 未执行 / 需外部账号的部分

- 创建专用 GitHub bot 账号、Fine-grained PAT、仓库 webhook（外部账号，仅给步骤）
- `ncl messaging-groups/wirings/users/members`（ncl 未安装、host 未运行）
- 从 `channels` 分支拷贝 `src/channels/github.ts` 与测试文件（本机无 NanoClaw 仓库）
- `pnpm run build` 与真实 `vitest run`（无项目可构建）
- 端到端消息投递（需服务运行 + 真实仓库）

## 依赖说明

仅安装 Skill 明确要求的 `@chat-adapter/github@4.29.0`（精确版本，无 `^`/`~`），
未引入任何额外依赖（无 devDependencies，验证脚本全部使用 node 内置模块）。
