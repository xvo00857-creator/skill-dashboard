#!/usr/bin/env bash
# ncl 接线命令模板（来源：SKILL.md「Wiring」）。
#
# 本文件只作为“确认前步骤”留存，不在本次执行：
#   - 本机未安装 ncl
#   - 没有运行中的 NanoClaw host 服务（ncl 通过 Unix socket 连接它）
#   - 需要真实的 agent-group-id 与仓库
# 待上述前置就绪后，按下述顺序执行；占位符需先替换。
set -euo pipefail

# 0) 先确认仓库可见性，决定 unknown-sender-policy
#    私有仓库 -> public （只有协作者能评论，放行即可）
#    公开仓库 -> strict （仅注册成员能触发 agent，防止陌生人消耗资源）
REPO_OWNER="__OWNER__"          # 例：acme
REPO_NAME="__REPO__"            # 例：backend
POLICY="public"                 # 或 strict
AGENT_GROUP_ID="__AGENT_GROUP_ID__"

# 1) 创建消息组（每个仓库一个）
ncl messaging-groups create \
  --channel-type github \
  --platform-id "github:${REPO_OWNER}/${REPO_NAME}" \
  --name "${REPO_OWNER}/${REPO_NAME}" \
  --is-group 1 \
  --unknown-sender-policy "${POLICY}"
# 从输出中拿到 <mg-id>

# 2) 接线到 agent 组；per-thread 让每个 PR/issue 拥有独立会话
MG_ID="__MG_ID_FROM_STEP_1__"
ncl wirings create \
  --messaging-group-id "${MG_ID}" \
  --agent-group-id "${AGENT_GROUP_ID}" \
  --session-mode per-thread

# 3) 仅 strict 模式：添加可信 GitHub 用户为成员
#    数字 ID 可用：gh api users/<username> --jq .id
# ncl users create --id "github:<numeric-user-id>" --kind github --display-name "<username>"
# ncl members add --user "github:<numeric-user-id>" --group "${AGENT_GROUP_ID}"

# 4) 重启服务以加载新渠道与 .env（SKILL.md「Next Steps」）
#    source setup/lib/install-slug.sh
#    launchctl kickstart -k gui/$(id -u)/$(launchd_label)   # macOS
#    systemctl --user restart $(systemd_unit)              # Linux
