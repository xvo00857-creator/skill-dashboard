#!/usr/bin/env bash
# 一键运行所有本地可重复验证。不依赖外部账号、不依赖 ncl/NanoClaw 项目。
set -euo pipefail
cd "$(dirname "$0")"

echo "########## 1/4 verify-import ##########"
node verify-import.mjs
echo

echo "########## 2/4 verify-registry ##########"
node verify-registry.mjs
echo

echo "########## 3/4 verify-webhook-signature ##########"
node verify-webhook-signature.mjs
echo

echo "########## 4/4 verify-env ##########"
bash verify-env.sh
echo

echo "########## 全部通过 ##########"
