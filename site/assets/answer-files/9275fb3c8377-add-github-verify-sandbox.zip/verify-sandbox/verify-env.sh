#!/usr/bin/env bash
# 验证 4：nc:env-set 的 set-if-absent 语义 + webhook secret 生成。
# SKILL.md：“set-if-absent — a value you've already filled in is never overwritten”。
# 使用 apply-fixtures.json 里的假值（nanoclaw-bot / fake-webhook-secret），
# token 用符合 Skill 要求的 github_pat_ 前缀假值；不接触任何真实凭据。
set -euo pipefail
cd "$(dirname "$0")"

ENV_FILE=.env.verify

# 幂等：先清掉旧的验证文件，保证可重复运行
rm -f "$ENV_FILE"

# 模拟 nc:prompt 绑定的三个值（假值）
GITHUB_TOKEN="REDACTED_FOR_PUBLIC_RELEASE"
GITHUB_WEBHOOK_SECRET="fake-webhook-secret"
GITHUB_BOT_USERNAME="nanoclaw-bot"

# set-if-absent 写入函数：键存在则不覆盖
env_set() {
  local key="$1" val="$2"
  if grep -qE "^${key}=" "$ENV_FILE" 2>/dev/null; then
    echo "skip(set-if-absent): ${key} 已存在，不覆盖"
  else
    printf '%s=%s\n' "$key" "$val" >> "$ENV_FILE"
    echo "wrote: ${key}"
  fi
}

echo "--- 第一次写入（应全部 wrote）---"
env_set GITHUB_TOKEN "$GITHUB_TOKEN"
env_set GITHUB_WEBHOOK_SECRET "$GITHUB_WEBHOOK_SECRET"
env_set GITHUB_BOT_USERNAME "$GITHUB_BOT_USERNAME"

echo "--- 第二次写入（应全部 skip，证明幂等）---"
env_set GITHUB_TOKEN "$GITHUB_TOKEN"
env_set GITHUB_WEBHOOK_SECRET "$GITHUB_WEBHOOK_SECRET"
env_set GITHUB_BOT_USERNAME "$GITHUB_BOT_USERNAME"

echo "--- openssl 生成 webhook secret（Skill 第 2 步：openssl rand -hex 20）---"
GEN_SECRET="$(openssl rand -hex 20)"
echo "generated(示例, 每次不同): ${GEN_SECRET}"
[ "${#GEN_SECRET}" -eq 40 ] || { echo "secret 长度应为 40 个十六进制字符"; exit 1; }

echo "--- 最终 .env.verify 内容 ---"
cat "$ENV_FILE"

# 断言三个键都在
grep -q '^GITHUB_TOKEN=' "$ENV_FILE"
grep -q '^GITHUB_WEBHOOK_SECRET=' "$ENV_FILE"
grep -q '^GITHUB_BOT_USERNAME=' "$ENV_FILE"
# 断言没有重复键
[ "$(grep -c '^GITHUB_TOKEN=' "$ENV_FILE")" -eq 1 ]
[ "$(grep -c '^GITHUB_WEBHOOK_SECRET=' "$ENV_FILE")" -eq 1 ]
[ "$(grep -c '^GITHUB_BOT_USERNAME=' "$ENV_FILE")" -eq 1 ]
echo "PASS verify-env: set-if-absent 幂等写入正确，三个环境变量齐全且无重复"
