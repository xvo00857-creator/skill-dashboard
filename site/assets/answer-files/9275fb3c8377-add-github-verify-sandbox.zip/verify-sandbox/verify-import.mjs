// 验证 1：Skill 第 3、4 步的核心断言——
// “适配器在 @chat-adapter/github 未安装时 import 会抛错；安装后可正常加载，
//  且渠道名为 github。”
// 这里直接 import 真实安装的精确版本包，不引入任何额外依赖。
import assert from 'node:assert/strict';
import * as github from '@chat-adapter/github';

const pkg = JSON.parse(
  // 仅用于回显已安装版本，证明锁定的是 4.29.0 而非 latest/范围版本
  (await import('node:fs')).readFileSync(
    new URL('./node_modules/@chat-adapter/github/package.json', import.meta.url),
    'utf8',
  ),
);

assert.equal(pkg.version, '4.29.0', `必须锁定 4.29.0，实际为 ${pkg.version}`);
assert.equal(typeof github.GitHubAdapter, 'function', '缺少命名导出 GitHubAdapter');
assert.equal(typeof github.createGitHubAdapter, 'function', '缺少命名导出 createGitHubAdapter');

const inst = new github.GitHubAdapter({
  token: 'REDACTED_FOR_PUBLIC_RELEASE',
  webhookSecret: 'fake-webhook-secret',
  userName: 'nanoclaw-bot',
});
assert.equal(inst.name, 'github', `渠道名应为 github，实际为 ${inst.name}`);

console.log('PASS verify-import: @chat-adapter/github@4.29.0 已安装、可导入，适配器 name=github');
