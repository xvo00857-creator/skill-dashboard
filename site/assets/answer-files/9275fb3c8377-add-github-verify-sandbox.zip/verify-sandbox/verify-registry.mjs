// 验证 2：模拟 github-registration.test.ts 的断言。
//
// 真实测试文件（src/channels/github-registration.test.ts）与 barrel
// （src/channels/index.ts）位于 NanoClaw 仓库的 channels 分支，本机不存在该仓库，
// 因此无法运行真实 vitest。这里用最小内存模型复现 SKILL.md 描述的自注册模式：
//   - barrel 中追加 `import './github.js';`
//   - 该 import 的副作用是把 { type:'github', adapter } 注册进 registry
//   - 测试断言 registry 包含 'github'
// 并验证幂等：重复追加同一 import 行不会产生重复注册。
import assert from 'node:assert/strict';

const registry = new Map();
// 模拟 github.ts 的自注册副作用
function loadGithubChannel() {
  if (registry.has('github')) return; // 幂等
  registry.set('github', { type: 'github', adapter: { name: 'github' } });
}
// 模拟 barrel index.ts 里的 import 行
const barrelLines = [];
function appendBarrelImport(line) {
  if (!barrelLines.includes(line)) barrelLines.push(line); // nc:append 的 skipped-if-present
}

// 第一次 apply
appendBarrelImport("import './github.js';");
for (const l of barrelLines) if (l === "import './github.js';") loadGithubChannel();
assert.ok(registry.has('github'), '注册后 registry 应包含 github');

// 重复 apply（幂等性）：不应抛错、不应重复
appendBarrelImport("import './github.js';");
for (const l of barrelLines) if (l === "import './github.js';") loadGithubChannel();
assert.equal(registry.size, 1, '重复 import 不应产生重复注册');
assert.equal(barrelLines.filter((l) => l === "import './github.js';").length, 1, 'barrel 中 import 行应唯一');

// 反例：若删掉 import 行，barrel 不再加载 github，registry 应不含 github
const registry2 = new Map();
const barrel2 = []; // 未追加 import
for (const l of barrel2) if (l === "import './github.js';") registry2.set('github', {});
assert.equal(registry2.has('github'), false, '缺少 import 行时 registry 不应含 github（对应测试变红）');

console.log('PASS verify-registry: 自注册/幂等断言通过（模拟 channels 分支缺失的真实测试）');
