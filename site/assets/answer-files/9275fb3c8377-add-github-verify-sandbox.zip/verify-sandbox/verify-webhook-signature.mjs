// 验证 3：webhook 密钥校验链路。
// SKILL.md 排障章：401 表示 webhook 表单里的 secret 与 GITHUB_WEBHOOK_SECRET 不一致。
// GitHub webhook 签名为 HMAC-SHA256，header 形如 X-Hub-Signature-256: sha256=<hex>。
// 这里用 node 内置 crypto 复现该校验，证明：
//   - 正确 secret -> 校验通过
//   - 错误 secret -> 校验失败（对应 401）
// 不引入任何额外依赖。
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

function sign(secret, payload) {
  return 'sha256=' + crypto.createHmac('sha256', secret).update(payload).digest('hex');
}
function verifySignature(secret, payload, signature) {
  const expected = sign(secret, payload);
  // 与适配器一致的恒定时间比较思路
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

const secret = 'fake-webhook-secret'; // 来自 apply-fixtures.json 的假值
const payload = JSON.stringify({ action: 'created', comment: { body: '@nanoclaw-bot hi' } });

const goodSig = sign(secret, payload);
assert.equal(verifySignature(secret, payload, goodSig), true, '正确 secret 应校验通过');
assert.equal(
  verifySignature('wrong-secret', payload, goodSig),
  false,
  '错误 secret 应校验失败（对应排障中的 401）',
);

console.log('PASS verify-webhook-signature: HMAC-SHA256 签名校验正确，secret 不一致时失败');
