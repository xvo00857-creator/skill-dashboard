# 内部设备登记系统（DeviceRegistry）

基于 .NET 8 + ASP.NET Core Minimal API + Clean Architecture + CQRS 的内部设备登记服务。

## 技术栈

- .NET 8 / C# 12
- ASP.NET Core Minimal API
- Entity Framework Core 8（SQL Server 提供程序，测试使用 InMemory）
- MediatR（CQRS 模式）
- FluentValidation（输入校验）
- JWT Bearer 认证
- Swagger / OpenAPI
- xUnit + WebApplicationFactory（集成测试）

## 项目结构

```
DeviceRegistry/
├── DeviceRegistry.sln
├── src/
│   ├── Domain/              # 领域层：实体、枚举、异常、业务不变量
│   ├── Application/         # 应用层：CQRS 命令/查询、DTO、验证器、接口
│   ├── Infrastructure/      # 基础设施层：DbContext、实体配置、DI 注册
│   └── WebApi/              # API 层：Minimal API 端点、Program.cs、配置
└── tests/
    └── Application.Tests.Integration/  # 集成测试
```

## 前置条件

- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)
- SQL Server 2019+（或 LocalDB 用于开发）
- 有效 JWT 签发服务（用于生成含角色声明的 Token）

## 配置说明

### 1. 数据库连接字符串

在 `src/WebApi/appsettings.json` 或环境变量中设置：

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=your-server;Database=DeviceRegistry;User Id=your-user;Password=your-password;TrustServerCertificate=True;"
  }
}
```

**安全要求**：生产环境数据库账户应使用最小权限（仅 `SELECT`、`INSERT`、`UPDATE`），禁止授予 `DROP`、`ALTER`、`TRUNCATE` 等权限。连接字符串不得硬编码在代码中，应通过密钥管理服务或环境变量注入。

### 2. JWT 配置

```json
{
  "JwtSettings": {
    "Secret": "your-strong-secret-key-at-least-32-characters",
    "Issuer": "DeviceRegistry",
    "Audience": "DeviceRegistryUsers",
    "ExpirationMinutes": 60
  }
}
```

**安全要求**：`Secret` 长度不得少于 32 字符。生产环境必须通过密钥管理服务注入，禁止写入配置文件或代码。启动时若密钥缺失或长度不足，服务将拒绝启动。

## 构建与运行

```bash
# 还原依赖
dotnet restore DeviceRegistry.sln

# 构建解决方案
dotnet build DeviceRegistry.sln --configuration Release

# 运行 API（开发环境）
cd src/WebApi
dotnet run --environment Development
```

启动后访问 Swagger 文档：`https://localhost:<port>/swagger`

## 数据库迁移

**重要：迁移不会在启动时自动执行。** 需人工在受控环境中执行以下命令：

```bash
# 生成迁移（首次）
dotnet ef migrations add InitialCreate --project src/Infrastructure --startup-project src/WebApi

# 应用迁移到数据库（需确认目标环境后执行）
dotnet ef database update --project src/Infrastructure --startup-project src/WebApi
```

执行迁移前必须确认：
1. 目标数据库环境正确（非生产误操作）
2. 迁移脚本已审核（无 DROP TABLE / TRUNCATE 等破坏性操作）
3. 已备份现有数据

## 运行测试

```bash
dotnet test DeviceRegistry.sln --configuration Release
```

测试使用 EF Core InMemory 数据库，不依赖外部 SQL Server，不执行任何外部写操作。

## API 端点

| 方法 | 路径 | 角色 | 说明 |
|------|------|------|------|
| GET | `/api/devices` | DeviceReader / DeviceAdmin | 分页查询设备列表，支持搜索与筛选 |
| GET | `/api/devices/{id}` | DeviceReader / DeviceAdmin | 按 ID 查询单台设备 |
| POST | `/api/devices` | DeviceAdmin | 登记新设备（初始状态 Registered） |
| PATCH | `/api/devices/{id}/status` | DeviceAdmin | 更新设备状态（仅允许合法流转） |
| GET | `/health` | 公开 | 健康检查 |

### 状态流转规则

```
Registered → InUse / InStock / UnderMaintenance / Retired
InUse      → InStock / UnderMaintenance / Retired
InStock    → InUse / UnderMaintenance / Retired
UnderMaintenance → InStock / Retired
Retired    → （终态，不可变更）
```

- 状态为 `InUse` 时必须指定使用人（`AssignedTo`）
- 已报废设备不可再变更状态
- 不提供删除接口，设备仅可报废，记录永久保留以满足审计要求

## 安全设计要点

1. **认证**：所有设备相关端点均要求 JWT 认证，健康检查除外。
2. **授权**：基于角色的最小权限策略，读操作与写操作分离。
3. **输入校验**：所有写操作通过 FluentValidation 校验，非法输入返回 400。
4. **领域不变量**：状态流转、资产编号唯一性、报废终态等规则在领域实体层强制执行。
5. **数据保护**：不直接暴露实体，统一通过 DTO 输出；不提供删除接口。
6. **异常处理**：全局异常中间件统一处理，生产环境不泄露堆栈信息。
7. **凭证管理**：连接字符串与 JWT 密钥从配置读取，启动时校验，缺失则拒绝启动。
8. **迁移安全**：不自动执行迁移，需人工审核后在受控环境执行。

## 已知限制

- 当前交付环境未安装 .NET 8 SDK，未执行 `dotnet build` 和 `dotnet test` 验证。请在安装 .NET 8 SDK 的环境中执行上述命令进行编译与测试验证。
- 未包含 Dockerfile / CI 配置（可根据部署环境后续补充）。
- 未包含用户管理/登录端点（JWT 由外部认证服务签发）。
