using Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Application.Common.Interfaces;

/// <summary>
/// 应用层数据上下文抽象。基础设施层提供实现，
/// 应用层仅依赖此接口，避免与 EF Core 具体实现耦合。
/// </summary>
public interface IApplicationDbContext
{
    DbSet<Device> Devices { get; }

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}
