using MediatR;

namespace Application.Devices.Commands.RegisterDevice;

/// <summary>
/// 登记新设备命令。状态由领域逻辑固定为 Registered，调用方不可指定。
/// </summary>
public record RegisterDeviceCommand(
    string AssetCode,
    string Name,
    string Category,
    string SerialNumber,
    string Location,
    string? AssignedTo = null) : IRequest<DeviceDto>;
