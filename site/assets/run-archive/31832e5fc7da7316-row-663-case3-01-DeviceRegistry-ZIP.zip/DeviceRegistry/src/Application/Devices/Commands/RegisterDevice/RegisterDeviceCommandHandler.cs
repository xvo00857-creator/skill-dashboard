using Application.Common.Interfaces;
using Domain.Entities;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Application.Devices.Commands.RegisterDevice;

public class RegisterDeviceCommandHandler
    : IRequestHandler<RegisterDeviceCommand, DeviceDto>
{
    private readonly IApplicationDbContext _context;

    public RegisterDeviceCommandHandler(IApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<DeviceDto> Handle(
        RegisterDeviceCommand request,
        CancellationToken cancellationToken)
    {
        // 资产编号全局唯一校验，防止重复登记。
        var exists = await _context.Devices
            .AsNoTracking()
            .AnyAsync(d => d.AssetCode == request.AssetCode.Trim(), cancellationToken);

        if (exists)
        {
            throw new InvalidOperationException($"资产编号 {request.AssetCode} 已存在。");
        }

        var device = Device.Register(
            request.AssetCode,
            request.Name,
            request.Category,
            request.SerialNumber,
            request.Location,
            request.AssignedTo);

        _context.Devices.Add(device);
        await _context.SaveChangesAsync(cancellationToken);

        return MapToDto(device);
    }

    private static DeviceDto MapToDto(Device device) => new(
        device.Id,
        device.AssetCode,
        device.Name,
        device.Category,
        device.SerialNumber,
        device.AssignedTo,
        device.Location,
        device.Status,
        device.CreatedAt,
        device.UpdatedAt);
}
