using FluentValidation;

namespace Application.Devices.Commands.RegisterDevice;

/// <summary>
/// 登记设备命令校验器。所有输入字段均经过长度与非空校验。
/// </summary>
public class RegisterDeviceCommandValidator : AbstractValidator<RegisterDeviceCommand>
{
    public RegisterDeviceCommandValidator()
    {
        RuleFor(x => x.AssetCode)
            .NotEmpty().WithMessage("资产编号不能为空。")
            .MaximumLength(50).WithMessage("资产编号长度不能超过 50。");

        RuleFor(x => x.Name)
            .NotEmpty().WithMessage("设备名称不能为空。")
            .MaximumLength(200).WithMessage("设备名称长度不能超过 200。");

        RuleFor(x => x.Category)
            .NotEmpty().WithMessage("设备类别不能为空。")
            .MaximumLength(50).WithMessage("设备类别长度不能超过 50。");

        RuleFor(x => x.SerialNumber)
            .NotEmpty().WithMessage("序列号不能为空。")
            .MaximumLength(100).WithMessage("序列号长度不能超过 100。");

        RuleFor(x => x.Location)
            .NotEmpty().WithMessage("所在位置不能为空。")
            .MaximumLength(200).WithMessage("所在位置长度不能超过 200。");

        RuleFor(x => x.AssignedTo)
            .MaximumLength(100).WithMessage("使用人长度不能超过 100。")
            .When(x => !string.IsNullOrWhiteSpace(x.AssignedTo));
    }
}
