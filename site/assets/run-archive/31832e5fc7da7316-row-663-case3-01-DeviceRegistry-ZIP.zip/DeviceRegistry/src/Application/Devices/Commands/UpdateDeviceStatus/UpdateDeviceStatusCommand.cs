using Domain.Enums;
using MediatR;

namespace Application.Devices.Commands.UpdateDeviceStatus;

/// <summary>
/// 更新设备状态命令。仅允许合法的状态流转，由领域实体强制执行。
/// </summary>
public record UpdateDeviceStatusCommand(
    int DeviceId,
    DeviceStatus NewStatus,
    string? AssignedTo = null) : IRequest<DeviceDto>;
