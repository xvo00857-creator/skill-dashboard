using Application.Common.Interfaces;
using Domain.Entities;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Application.Devices.Commands.UpdateDeviceStatus;

public class UpdateDeviceStatusCommandHandler
    : IRequestHandler<UpdateDeviceStatusCommand, DeviceDto>
{
    private readonly IApplicationDbContext _context;

    public UpdateDeviceStatusCommandHandler(IApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<DeviceDto> Handle(
        UpdateDeviceStatusCommand request,
        CancellationToken cancellationToken)
    {
        var device = await _context.Devices
            .FirstOrDefaultAsync(d => d.Id == request.DeviceId, cancellationToken);

        if (device is null)
        {
            throw new KeyNotFoundException($"设备 ID {request.DeviceId} 不存在。");
        }

        // 领域实体内部校验状态流转合法性、报废终态、使用人必填等规则。
        device.UpdateStatus(request.NewStatus, request.AssignedTo);
        await _context.SaveChangesAsync(cancellationToken);

        return MapToDto(device);
    }

    private static DeviceDto MapToDto(Device device) => new(
        device.Id,
        device.AssetCode,
        device.Name,
        device.Category,
        device.SerialNumber,
        device.AssignedTo,
        device.Location,
        device.Status,
        device.CreatedAt,
        device.UpdatedAt);
}
