using Domain.Enums;
using FluentValidation;

namespace Application.Devices.Commands.UpdateDeviceStatus;

/// <summary>
/// 状态更新命令校验器。
/// </summary>
public class UpdateDeviceStatusCommandValidator : AbstractValidator<UpdateDeviceStatusCommand>
{
    public UpdateDeviceStatusCommandValidator()
    {
        RuleFor(x => x.DeviceId)
            .GreaterThan(0).WithMessage("设备 ID 必须大于 0。");

        RuleFor(x => x.NewStatus)
            .IsInEnum().WithMessage("无效的设备状态。");

        // 当目标状态为 InUse 时，使用人必填（领域层也会再次校验，此处提前拦截）。
        RuleFor(x => x.AssignedTo)
            .NotEmpty().WithMessage("启用状态必须指定使用人。")
            .When(x => x.NewStatus == DeviceStatus.InUse);

        RuleFor(x => x.AssignedTo)
            .MaximumLength(100).WithMessage("使用人长度不能超过 100。")
            .When(x => !string.IsNullOrWhiteSpace(x.AssignedTo));
    }
}
