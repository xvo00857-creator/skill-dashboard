using Domain.Enums;

namespace Application.Devices;

/// <summary>
/// 设备数据传输对象。API 响应只返回 DTO，不直接暴露领域实体。
/// </summary>
public record DeviceDto(
    int Id,
    string AssetCode,
    string Name,
    string Category,
    string SerialNumber,
    string? AssignedTo,
    string Location,
    DeviceStatus Status,
    DateTime CreatedAt,
    DateTime? UpdatedAt);
