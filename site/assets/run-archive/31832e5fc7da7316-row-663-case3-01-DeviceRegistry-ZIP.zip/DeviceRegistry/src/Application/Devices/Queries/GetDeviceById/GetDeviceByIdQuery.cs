using MediatR;

namespace Application.Devices.Queries.GetDeviceById;

/// <summary>
/// 按 ID 查询单台设备。
/// </summary>
public record GetDeviceByIdQuery(int Id) : IRequest<DeviceDto?>;
