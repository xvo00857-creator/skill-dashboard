using Application.Common.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Application.Devices.Queries.GetDeviceById;

public class GetDeviceByIdQueryHandler
    : IRequestHandler<GetDeviceByIdQuery, DeviceDto?>
{
    private readonly IApplicationDbContext _context;

    public GetDeviceByIdQueryHandler(IApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<DeviceDto?> Handle(
        GetDeviceByIdQuery request,
        CancellationToken cancellationToken)
    {
        return await _context.Devices
            .AsNoTracking()
            .Where(d => d.Id == request.Id)
            .Select(d => new DeviceDto(
                d.Id,
                d.AssetCode,
                d.Name,
                d.Category,
                d.SerialNumber,
                d.AssignedTo,
                d.Location,
                d.Status,
                d.CreatedAt,
                d.UpdatedAt))
            .FirstOrDefaultAsync(cancellationToken);
    }
}
