using Application.Common.Models;
using Domain.Enums;
using MediatR;

namespace Application.Devices.Queries.GetDevices;

/// <summary>
/// 分页查询设备列表，支持按资产编号、名称、类别、状态筛选。
/// </summary>
public record GetDevicesQuery(
    int Page = 1,
    int PageSize = 10,
    string? SearchTerm = null,
    DeviceStatus? Status = null,
    string? Category = null) : IRequest<PagedResult<DeviceDto>>;
