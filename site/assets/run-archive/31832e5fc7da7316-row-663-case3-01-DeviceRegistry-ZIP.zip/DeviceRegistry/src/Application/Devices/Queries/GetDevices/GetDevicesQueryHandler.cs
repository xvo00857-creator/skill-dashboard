using Application.Common.Interfaces;
using Application.Common.Models;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Application.Devices.Queries.GetDevices;

public class GetDevicesQueryHandler
    : IRequestHandler<GetDevicesQuery, PagedResult<DeviceDto>>
{
    private readonly IApplicationDbContext _context;

    public GetDevicesQueryHandler(IApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<PagedResult<DeviceDto>> Handle(
        GetDevicesQuery request,
        CancellationToken cancellationToken)
    {
        var query = _context.Devices.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(request.SearchTerm))
        {
            var term = request.SearchTerm.Trim();
            query = query.Where(d =>
                d.AssetCode.Contains(term) ||
                d.Name.Contains(term) ||
                d.SerialNumber.Contains(term));
        }

        if (request.Status.HasValue)
        {
            query = query.Where(d => d.Status == request.Status.Value);
        }

        if (!string.IsNullOrWhiteSpace(request.Category))
        {
            query = query.Where(d => d.Category == request.Category.Trim());
        }

        var totalCount = await query.CountAsync(cancellationToken);

        var items = await query
            .OrderByDescending(d => d.CreatedAt)
            .Skip((request.Page - 1) * request.PageSize)
            .Take(request.PageSize)
            .Select(d => new DeviceDto(
                d.Id,
                d.AssetCode,
                d.Name,
                d.Category,
                d.SerialNumber,
                d.AssignedTo,
                d.Location,
                d.Status,
                d.CreatedAt,
                d.UpdatedAt))
            .ToListAsync(cancellationToken);

        return new PagedResult<DeviceDto>(
            items,
            totalCount,
            request.Page,
            request.PageSize);
    }
}
