using Domain.Enums;
using Domain.Exceptions;

namespace Domain.Entities;

/// <summary>
/// 内部设备登记实体。所有属性变更通过公开方法执行，保证业务不变量。
/// 实体不直接暴露于 API 响应，统一通过 DTO 输出。
/// </summary>
public class Device
{
    public int Id { get; private set; }

    /// <summary>设备资产编号，全局唯一，由业务方分配。</summary>
    public string AssetCode { get; private set; } = string.Empty;

    /// <summary>设备名称/型号描述。</summary>
    public string Name { get; private set; } = string.Empty;

    /// <summary>设备类别，如 Laptop、Monitor、Phone。</summary>
    public string Category { get; private set; } = string.Empty;

    /// <summary>序列号，厂商唯一标识。</summary>
    public string SerialNumber { get; private set; } = string.Empty;

    /// <summary>当前使用人，可为空（库存/维修状态）。</summary>
    public string? AssignedTo { get; private set; }

    /// <summary>设备所在位置/部门。</summary>
    public string Location { get; private set; } = string.Empty;

    public DeviceStatus Status { get; private set; }

    public DateTime CreatedAt { get; private set; }

    public DateTime? UpdatedAt { get; private set; }

    /// <summary>EF Core 所需的无参构造函数，对外不公开。</summary>
    private Device() { }

    /// <summary>
    /// 登记新设备。初始状态固定为 Registered，不允许调用方直接指定其他状态。
    /// </summary>
    public static Device Register(
        string assetCode,
        string name,
        string category,
        string serialNumber,
        string location,
        string? assignedTo = null)
    {
        if (string.IsNullOrWhiteSpace(assetCode))
            throw new DomainException("资产编号不能为空。");
        if (string.IsNullOrWhiteSpace(name))
            throw new DomainException("设备名称不能为空。");
        if (string.IsNullOrWhiteSpace(category))
            throw new DomainException("设备类别不能为空。");
        if (string.IsNullOrWhiteSpace(serialNumber))
            throw new DomainException("序列号不能为空。");
        if (string.IsNullOrWhiteSpace(location))
            throw new DomainException("所在位置不能为空。");

        return new Device
        {
            AssetCode = assetCode.Trim(),
            Name = name.Trim(),
            Category = category.Trim(),
            SerialNumber = serialNumber.Trim(),
            Location = location.Trim(),
            AssignedTo = string.IsNullOrWhiteSpace(assignedTo) ? null : assignedTo.Trim(),
            Status = DeviceStatus.Registered,
            CreatedAt = DateTime.UtcNow
        };
    }

    /// <summary>
    /// 更新设备状态。仅允许合法的状态流转，报废后不可再变更。
    /// </summary>
    public void UpdateStatus(DeviceStatus newStatus, string? assignedTo = null)
    {
        if (Status == DeviceStatus.Retired)
            throw new DomainException("已报废设备不可变更状态。");

        if (!IsValidTransition(Status, newStatus))
            throw new DomainException(
                $"不允许从 {Status} 直接变更为 {newStatus}。");

        Status = newStatus;
        AssignedTo = newStatus switch
        {
            DeviceStatus.InUse => string.IsNullOrWhiteSpace(assignedTo)
                ? throw new DomainException("启用状态必须指定使用人。")
                : assignedTo.Trim(),
            DeviceStatus.InStock or DeviceStatus.UnderMaintenance or DeviceStatus.Retired => null,
            _ => AssignedTo
        };
        UpdatedAt = DateTime.UtcNow;
    }

    /// <summary>
    /// 合法状态流转矩阵。
    /// Registered -> InUse / InStock / UnderMaintenance / Retired
    /// InUse -> InStock / UnderMaintenance / Retired
    /// InStock -> InUse / UnderMaintenance / Retired
    /// UnderMaintenance -> InStock / Retired
    /// Retired -> （终态，不可流转）
    /// </summary>
    private static bool IsValidTransition(DeviceStatus from, DeviceStatus to) =>
        (from, to) switch
        {
            (DeviceStatus.Registered, DeviceStatus.InUse) => true,
            (DeviceStatus.Registered, DeviceStatus.InStock) => true,
            (DeviceStatus.Registered, DeviceStatus.UnderMaintenance) => true,
            (DeviceStatus.Registered, DeviceStatus.Retired) => true,
            (DeviceStatus.InUse, DeviceStatus.InStock) => true,
            (DeviceStatus.InUse, DeviceStatus.UnderMaintenance) => true,
            (DeviceStatus.InUse, DeviceStatus.Retired) => true,
            (DeviceStatus.InStock, DeviceStatus.InUse) => true,
            (DeviceStatus.InStock, DeviceStatus.UnderMaintenance) => true,
            (DeviceStatus.InStock, DeviceStatus.Retired) => true,
            (DeviceStatus.UnderMaintenance, DeviceStatus.InStock) => true,
            (DeviceStatus.UnderMaintenance, DeviceStatus.Retired) => true,
            _ => false
        };
}
