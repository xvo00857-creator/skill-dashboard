namespace Domain.Enums;

/// <summary>
/// 设备登记状态。状态流转受业务规则约束，不可任意跳转。
/// </summary>
public enum DeviceStatus
{
    /// <summary>已登记，待分配使用人。</summary>
    Registered = 0,

    /// <summary>已分配给使用人，正常使用中。</summary>
    InUse = 1,

    /// <summary>设备归还，处于库存待分配状态。</summary>
    InStock = 2,

    /// <summary>设备维修中，暂不可用。</summary>
    UnderMaintenance = 3,

    /// <summary>设备已报废，只读保留记录。</summary>
    Retired = 4
}
