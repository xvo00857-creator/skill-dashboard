namespace Domain.Exceptions;

/// <summary>
/// 领域异常，用于表达业务规则违反而非技术故障。
/// </summary>
public class DomainException : Exception
{
    public DomainException(string message) : base(message)
    {
    }

    public DomainException(string message, Exception innerException)
        : base(message, innerException)
    {
    }
}
