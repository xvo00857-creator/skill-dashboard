using Application.Common.Interfaces;
using Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Infrastructure;

/// <summary>
/// 基础设施层依赖注入注册。
/// 数据库连接字符串从配置读取，不硬编码。
/// 生产环境必须使用最小权限的数据库账户（仅 SELECT/INSERT/UPDATE，无 DROP/ALTER）。
/// </summary>
public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("DefaultConnection");

        if (string.IsNullOrWhiteSpace(connectionString))
        {
            // 连接字符串缺失时不静默回退到本地默认值，抛出明确异常。
            // 这是安全边界：防止在无凭证情况下意外连接错误数据库。
            throw new InvalidOperationException(
                "数据库连接字符串 DefaultConnection 未配置。请在 appsettings.json 或环境变量中设置后再启动。");
        }

        services.AddDbContext<ApplicationDbContext>(options =>
            options.UseSqlServer(
                connectionString,
                b => b.MigrationsAssembly(typeof(ApplicationDbContext).Assembly.FullName)));

        services.AddScoped<IApplicationDbContext>(provider =>
            provider.GetRequiredService<ApplicationDbContext>());

        return services;
    }
}
