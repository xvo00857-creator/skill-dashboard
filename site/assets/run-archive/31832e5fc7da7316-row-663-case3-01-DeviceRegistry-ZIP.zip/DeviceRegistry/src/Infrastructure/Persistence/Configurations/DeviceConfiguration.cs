using Domain.Entities;
using Domain.Enums;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configurations;

/// <summary>
/// Device 实体数据库配置。定义表结构、索引、字段约束。
/// 不包含种子数据（HasData），避免在迁移中覆盖或预置生产数据。
/// </summary>
public class DeviceConfiguration : IEntityTypeConfiguration<Device>
{
    public void Configure(EntityTypeBuilder<Device> builder)
    {
        builder.ToTable("Devices");

        builder.HasKey(d => d.Id);

        builder.Property(d => d.AssetCode)
            .IsRequired()
            .HasMaxLength(50);

        builder.Property(d => d.Name)
            .IsRequired()
            .HasMaxLength(200);

        builder.Property(d => d.Category)
            .IsRequired()
            .HasMaxLength(50);

        builder.Property(d => d.SerialNumber)
            .IsRequired()
            .HasMaxLength(100);

        builder.Property(d => d.AssignedTo)
            .HasMaxLength(100);

        builder.Property(d => d.Location)
            .IsRequired()
            .HasMaxLength(200);

        // 状态以字符串存储，便于可读性，同时 EF 自动处理枚举映射。
        builder.Property(d => d.Status)
            .HasConversion<string>()
            .HasMaxLength(20)
            .IsRequired();

        builder.Property(d => d.CreatedAt)
            .IsRequired();

        // 资产编号全局唯一索引，防止重复登记。
        builder.HasIndex(d => d.AssetCode)
            .IsUnique()
            .HasDatabaseName("IX_Devices_AssetCode");

        builder.HasIndex(d => d.SerialNumber)
            .HasDatabaseName("IX_Devices_SerialNumber");

        builder.HasIndex(d => d.Status)
            .HasDatabaseName("IX_Devices_Status");

        builder.HasIndex(d => d.Category)
            .HasDatabaseName("IX_Devices_Category");
    }
}
