using Application.Common.Models;
using Application.Devices;
using Application.Devices.Commands.RegisterDevice;
using Application.Devices.Commands.UpdateDeviceStatus;
using Application.Devices.Queries.GetDeviceById;
using Application.Devices.Queries.GetDevices;
using Domain.Enums;
using MediatR;

namespace WebApi.Endpoints;

/// <summary>
/// 设备登记系统 Minimal API 端点。
/// 所有写操作（新增、状态更新）要求 DeviceAdmin 角色。
/// 所有读操作要求 DeviceReader 或 DeviceAdmin 角色。
/// 不提供删除接口——设备仅可报废（Retired），记录永久保留以满足审计要求。
/// </summary>
public static class DeviceEndpoints
{
    public static IEndpointRouteBuilder MapDeviceEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/devices")
            .WithTags("Devices")
            .WithOpenApi();

        // ---------- 查询：分页列表 ----------
        group.MapGet("/", async (
            [AsParameters] GetDevicesQuery query,
            ISender sender,
            CancellationToken ct) =>
        {
            var result = await sender.Send(query, ct);
            return Results.Ok(result);
        })
        .RequireAuthorization("DeviceReader")
        .Produces<PagedResult<DeviceDto>>(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status401Unauthorized)
        .Produces(StatusCodes.Status403Forbidden);

        // ---------- 查询：单台设备 ----------
        group.MapGet("/{id:int}", async (
            int id,
            ISender sender,
            CancellationToken ct) =>
        {
            var result = await sender.Send(new GetDeviceByIdQuery(id), ct);
            return result is null
                ? Results.NotFound(new { title = "设备不存在。" })
                : Results.Ok(result);
        })
        .RequireAuthorization("DeviceReader")
        .Produces<DeviceDto>(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status404NotFound)
        .Produces(StatusCodes.Status401Unauthorized)
        .Produces(StatusCodes.Status403Forbidden);

        // ---------- 新增：登记设备 ----------
        group.MapPost("/", async (
            RegisterDeviceCommand command,
            ISender sender,
            CancellationToken ct) =>
        {
            var result = await sender.Send(command, ct);
            return Results.Created($"/api/devices/{result.Id}", result);
        })
        .RequireAuthorization("DeviceAdmin")
        .Produces<DeviceDto>(StatusCodes.Status201Created)
        .ProducesValidationProblem(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status401Unauthorized)
        .Produces(StatusCodes.Status403Forbidden);

        // ---------- 更新：设备状态 ----------
        group.MapPatch("/{id:int}/status", async (
            int id,
            UpdateDeviceStatusRequest request,
            ISender sender,
            CancellationToken ct) =>
        {
            var command = new UpdateDeviceStatusCommand(id, request.NewStatus, request.AssignedTo);
            var result = await sender.Send(command, ct);
            return Results.Ok(result);
        })
        .RequireAuthorization("DeviceAdmin")
        .Produces<DeviceDto>(StatusCodes.Status200OK)
        .ProducesValidationProblem(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status404NotFound)
        .Produces(StatusCodes.Status401Unauthorized)
        .Produces(StatusCodes.Status403Forbidden);

        return app;
    }
}

/// <summary>
/// 状态更新请求体。与命令分离，避免直接暴露 MediatR 契约。
/// </summary>
public record UpdateDeviceStatusRequest(
    DeviceStatus NewStatus,
    string? AssignedTo = null);
