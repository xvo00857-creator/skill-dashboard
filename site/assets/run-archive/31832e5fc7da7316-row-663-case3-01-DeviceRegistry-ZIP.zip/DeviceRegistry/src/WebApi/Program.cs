using System.Text;
using Application;
using Infrastructure;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using WebApi.Endpoints;

var builder = WebApplication.CreateBuilder(args);

// ---------- 服务注册 ----------
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddApplication();
builder.Services.AddInfrastructure(builder.Configuration);

// ---------- JWT 认证配置 ----------
// 密钥、颁发者、受众均从配置读取，禁止硬编码。
// 生产环境必须通过密钥管理服务（如 KMS / 环境变量 / Secret Manager）注入。
var jwtSecret = builder.Configuration["JwtSettings:Secret"];
if (string.IsNullOrWhiteSpace(jwtSecret) || jwtSecret.Length < 32)
{
    // 密钥缺失或长度不足时不启动，防止使用弱密钥或空密钥。
    throw new InvalidOperationException(
        "JWT 密钥 JwtSettings:Secret 未配置或长度不足 32 字符。请在生产环境配置强密钥后再启动。");
}

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(jwtSecret)),
        ValidateIssuer = true,
        ValidIssuer = builder.Configuration["JwtSettings:Issuer"],
        ValidateAudience = true,
        ValidAudience = builder.Configuration["JwtSettings:Audience"],
        ValidateLifetime = true,
        ClockSkew = TimeSpan.Zero
    };
});

// 授权策略：最小权限原则。
// DeviceReader：仅可查询。
// DeviceAdmin：可新增设备与更新状态。
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("DeviceReader", policy =>
        policy.RequireRole("DeviceReader", "DeviceAdmin"));
    options.AddPolicy("DeviceAdmin", policy =>
        policy.RequireRole("DeviceAdmin"));
});

var app = builder.Build();

// ---------- 中间件管道 ----------
// 全局异常处理：不向客户端泄露堆栈信息。
app.UseExceptionHandler(exceptionHandlerApp =>
{
    exceptionHandlerApp.Run(async context =>
    {
        var feature = context.Features.Get<IExceptionHandlerFeature>();
        var ex = feature?.Error;

        var (statusCode, title) = ex switch
        {
            InvalidOperationException => (StatusCodes.Status400BadRequest, "请求无效。"),
            KeyNotFoundException => (StatusCodes.Status404NotFound, "资源不存在。"),
            FluentValidation.ValidationException ve => (StatusCodes.Status400BadRequest, "校验失败。"),
            _ => (StatusCodes.Status500InternalServerError, "服务器内部错误。")
        };

        context.Response.StatusCode = statusCode;
        await context.Response.WriteAsJsonAsync(new
        {
            title,
            status = statusCode,
            // 仅在开发环境返回异常消息，生产环境隐藏细节。
            detail = app.Environment.IsDevelopment() ? ex?.Message : null
        });
    });
});

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

// ---------- 端点映射 ----------
app.MapDeviceEndpoints();

// 健康检查端点（无需认证，供负载均衡/容器编排使用）。
app.MapGet("/health", () => Results.Ok(new { status = "healthy" }))
    .WithName("HealthCheck")
    .WithOpenApi();

app.Run();

// 显式声明 Program 类，供 WebApplicationFactory<Program> 集成测试引用。
public partial class Program { }
