using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Application.Devices;
using Domain.Entities;
using Domain.Enums;
using Infrastructure.Persistence;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Application.Tests.Integration;

/// <summary>
/// 设备登记系统 API 集成测试。
/// 覆盖：新增、查询（列表/单条）、状态更新、认证授权、输入校验、非法状态流转。
/// 所有测试使用 InMemory 数据库，不连接真实数据库，不执行外部写操作。
/// </summary>
public class DeviceEndpointsTests : IClassFixture<TestWebApplicationFactory>
{
    private readonly TestWebApplicationFactory _factory;
    private readonly HttpClient _client;

    public DeviceEndpointsTests(TestWebApplicationFactory factory)
    {
        _factory = factory;
        _client = factory.CreateClient();
    }

    /// <summary>
    /// 生成测试用 JWT（仅测试用途，不涉及真实认证服务）。
    /// </summary>
    private static string GenerateTestJwt(string role)
    {
        // 测试用密钥，与 TestWebApplicationFactory 中配置一致。
        const string secret = "test-secret-key-for-integration-tests-only-32chars-min";
        var key = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(secret));
        var credentials = new Microsoft.IdentityModel.Tokens.SigningCredentials(
            key, Microsoft.IdentityModel.Tokens.SecurityAlgorithms.HmacSha256);

        var claims = new[]
        {
            new System.Security.Claims.Claim(
                System.Security.Claims.ClaimTypes.NameIdentifier, "1"),
            new System.Security.Claims.Claim(
                System.Security.Claims.ClaimTypes.Email, "test@example.com"),
            new System.Security.Claims.Claim(
                System.Security.Claims.ClaimTypes.Role, role)
        };

        var token = new System.IdentityModel.Tokens.Jwt.JwtSecurityToken(
            issuer: "DeviceRegistry-Test",
            audience: "DeviceRegistry-TestUsers",
            claims: claims,
            expires: DateTime.UtcNow.AddHours(1),
            signingCredentials: credentials);

        return new System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler().WriteToken(token);
    }

    private void SetAuthHeader(string role)
    {
        _client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", GenerateTestJwt(role));
    }

    private void ClearAuthHeader()
    {
        _client.DefaultRequestHeaders.Authorization = null;
    }

    // ---------- 认证授权测试 ----------

    [Fact]
    public async Task GetDevices_WithoutToken_ReturnsUnauthorized()
    {
        ClearAuthHeader();
        var response = await _client.GetAsync("/api/devices");
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task PostDevice_AsReader_ReturnsForbidden()
    {
        SetAuthHeader("DeviceReader");
        var command = new { AssetCode = "A001", Name = "Test", Category = "Laptop", SerialNumber = "SN001", Location = "Beijing" };
        var response = await _client.PostAsJsonAsync("/api/devices", command);
        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    // ---------- 新增设备测试 ----------

    [Fact]
    public async Task PostDevice_AsAdmin_WithValidData_ReturnsCreated()
    {
        SetAuthHeader("DeviceAdmin");
        var command = new { AssetCode = "NEW001", Name = "ThinkPad X1", Category = "Laptop", SerialNumber = "SN-NEW-001", Location = "Beijing" };
        var response = await _client.PostAsJsonAsync("/api/devices", command);
        Assert.Equal(HttpStatusCode.Created, response.StatusCode);

        var dto = await response.Content.ReadFromJsonAsync<DeviceDto>();
        Assert.NotNull(dto);
        Assert.Equal("NEW001", dto.AssetCode);
        Assert.Equal(DeviceStatus.Registered, dto.Status);
    }

    [Fact]
    public async Task PostDevice_WithMissingFields_ReturnsBadRequest()
    {
        SetAuthHeader("DeviceAdmin");
        var command = new { AssetCode = "", Name = "", Category = "", SerialNumber = "", Location = "" };
        var response = await _client.PostAsJsonAsync("/api/devices", command);
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task PostDevice_WithDuplicateAssetCode_ReturnsBadRequest()
    {
        SetAuthHeader("DeviceAdmin");
        var command = new { AssetCode = "DUP001", Name = "Device 1", Category = "Laptop", SerialNumber = "SN-DUP-001", Location = "Beijing" };
        await _client.PostAsJsonAsync("/api/devices", command);

        var duplicate = new { AssetCode = "DUP001", Name = "Device 2", Category = "Monitor", SerialNumber = "SN-DUP-002", Location = "Shanghai" };
        var response = await _client.PostAsJsonAsync("/api/devices", duplicate);
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    // ---------- 查询测试 ----------

    [Fact]
    public async Task GetDeviceById_AsReader_WithExistingId_ReturnsOk()
    {
        // 前置：通过 Admin 新增一台设备。
        SetAuthHeader("DeviceAdmin");
        var createCmd = new { AssetCode = "GET001", Name = "Get Test", Category = "Phone", SerialNumber = "SN-GET-001", Location = "Guangzhou" };
        var createResp = await _client.PostAsJsonAsync("/api/devices", createCmd);
        var created = await createResp.Content.ReadFromJsonAsync<DeviceDto>();

        // 切换为 Reader 角色查询。
        SetAuthHeader("DeviceReader");
        var response = await _client.GetAsync($"/api/devices/{created!.Id}");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var dto = await response.Content.ReadFromJsonAsync<DeviceDto>();
        Assert.NotNull(dto);
        Assert.Equal("GET001", dto.AssetCode);
    }

    [Fact]
    public async Task GetDeviceById_WithNonExistingId_ReturnsNotFound()
    {
        SetAuthHeader("DeviceReader");
        var response = await _client.GetAsync("/api/devices/99999");
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task GetDevices_AsReader_ReturnsPagedResult()
    {
        SetAuthHeader("DeviceReader");
        var response = await _client.GetAsync("/api/devices?page=1&pageSize=10");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    // ---------- 状态更新测试 ----------

    [Fact]
    public async Task PatchStatus_AsAdmin_ValidTransition_ReturnsOk()
    {
        SetAuthHeader("DeviceAdmin");
        var createCmd = new { AssetCode = "STA001", Name = "Status Test", Category = "Laptop", SerialNumber = "SN-STA-001", Location = "Beijing" };
        var createResp = await _client.PostAsJsonAsync("/api/devices", createCmd);
        var created = await createResp.Content.ReadFromJsonAsync<DeviceDto>();

        var request = new { NewStatus = "InUse", AssignedTo = "zhangsan" };
        var response = await _client.PatchAsJsonAsync($"/api/devices/{created!.Id}/status", request);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var dto = await response.Content.ReadFromJsonAsync<DeviceDto>();
        Assert.NotNull(dto);
        Assert.Equal(DeviceStatus.InUse, dto.Status);
        Assert.Equal("zhangsan", dto.AssignedTo);
    }

    [Fact]
    public async Task PatchStatus_InUseWithoutAssignedTo_ReturnsBadRequest()
    {
        SetAuthHeader("DeviceAdmin");
        var createCmd = new { AssetCode = "STA002", Name = "Status Test 2", Category = "Laptop", SerialNumber = "SN-STA-002", Location = "Beijing" };
        var createResp = await _client.PostAsJsonAsync("/api/devices", createCmd);
        var created = await createResp.Content.ReadFromJsonAsync<DeviceDto>();

        var request = new { NewStatus = "InUse", AssignedTo = (string?)null };
        var response = await _client.PatchAsJsonAsync($"/api/devices/{created!.Id}/status", request);
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task PatchStatus_RetiredThenUpdate_ReturnsBadRequest()
    {
        SetAuthHeader("DeviceAdmin");
        var createCmd = new { AssetCode = "STA003", Name = "Status Test 3", Category = "Laptop", SerialNumber = "SN-STA-003", Location = "Beijing" };
        var createResp = await _client.PostAsJsonAsync("/api/devices", createCmd);
        var created = await createResp.Content.ReadFromJsonAsync<DeviceDto>();

        // 先报废。
        await _client.PatchAsJsonAsync($"/api/devices/{created!.Id}/status", new { NewStatus = "Retired" });

        // 报废后再尝试变更状态，应失败。
        var response = await _client.PatchAsJsonAsync($"/api/devices/{created.Id}/status", new { NewStatus = "InStock" });
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task PatchStatus_AsReader_ReturnsForbidden()
    {
        SetAuthHeader("DeviceAdmin");
        var createCmd = new { AssetCode = "STA004", Name = "Status Test 4", Category = "Laptop", SerialNumber = "SN-STA-004", Location = "Beijing" };
        var createResp = await _client.PostAsJsonAsync("/api/devices", createCmd);
        var created = await createResp.Content.ReadFromJsonAsync<DeviceDto>();

        SetAuthHeader("DeviceReader");
        var response = await _client.PatchAsJsonAsync($"/api/devices/{created!.Id}/status", new { NewStatus = "InStock" });
        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }
}
