using Infrastructure.Persistence;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Application.Tests.Integration;

/// <summary>
/// 集成测试 WebApplication 工厂。
/// 使用 EF Core InMemory 数据库替代真实 SQL Server，避免测试依赖外部数据库。
/// 覆盖 JWT 配置以满足 Program.cs 中的密钥长度校验。
/// 不执行任何迁移或外部写操作。
/// </summary>
public class TestWebApplicationFactory : WebApplicationFactory<Program>
{
    /// <summary>
    /// 测试用数据库名称，每个工厂实例独立，避免测试间数据污染。
    /// </summary>
    private readonly string _databaseName = $"TestDb_{Guid.NewGuid():N}";

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");

        builder.ConfigureServices(services =>
        {
            // 移除已注册的 ApplicationDbContext（真实 SQL Server 配置）。
            var descriptor = services.SingleOrDefault(
                d => d.ServiceType == typeof(DbContextOptions<ApplicationDbContext>));
            if (descriptor is not null)
            {
                services.Remove(descriptor);
            }

            // 注册 InMemory 数据库用于测试。
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseInMemoryDatabase(_databaseName));
        });

        // 覆盖 JWT 配置，提供测试用密钥（满足 >=32 字符要求）。
        builder.UseSetting("JwtSettings:Secret",
            "test-secret-key-for-integration-tests-only-32chars-min");
        builder.UseSetting("JwtSettings:Issuer", "DeviceRegistry-Test");
        builder.UseSetting("JwtSettings:Audience", "DeviceRegistry-TestUsers");
    }

    /// <summary>
    /// 获取测试用 DbContext 实例，用于测试前置数据准备和断言。
    /// </summary>
    public ApplicationDbContext GetDbContext()
    {
        var scope = Services.CreateScope();
        return scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    }
}
